This is a red herring.
