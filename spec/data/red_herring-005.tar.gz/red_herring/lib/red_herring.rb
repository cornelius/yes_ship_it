require_relative "version.rb"

def magic
  "magic"
end
